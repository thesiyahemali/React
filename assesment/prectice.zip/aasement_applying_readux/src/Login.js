import React from 'react'

const Login = () => {
  return (
    <>
     
    {/* <h2>Login</h2>
    <form action="#" method="post" />
      <input type="text" name="phone" placeholder="Phone Number" required />
      <input type="password" name="password" placeholder="Password" required />
      <button type="submit">Login</button>
    <form/ > */}
  
    </>
  )
}

export default Login